<?php

class Mrecords extends CI_Model
{
	public function showtime()
	{
		echo time();
	}
	public function showrecords()
	{
		$CI=&get_instance();
		$result=$CI->db->get('records')->result_array();
		return $result;
	}
}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Records extends CI_Controller {

	public function index()
	{
		$this->load->model('mrecords');
		$records=$this->mrecords->showrecords();
		$this->load->view('list_records',array('records'=>$records));
	}
}

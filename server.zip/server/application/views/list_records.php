<?php /*<!DOCTYPE html>
<html>
    <head>
    <title>Таблица рекордов</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    	<link href="http://twitter.github.com/bootstrap/assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<meta http-equiv="Content-Type" content="text/html"; charset="utf-8">
</head>
<body>
    <h1>Records table</h1>
	<table class="table table-stripped">
	<?php
		foreach($records as $key=>$value)
		{
			echo '<tr>';
				echo '<td>';
					echo $value['recordId'];
				echo '</td>';
				echo '<td>';
					echo $value['recordUserName'];
				echo '</td>';
				echo '<td>';
					echo $value['recordDate'];
				echo '</td>';
				echo '<td>';
					echo $value['recordSpeed'];
				echo '</td>';
			echo '</tr>';
		}
	?>
	</table>
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://twitter.github.com/bootstrap/assets/js/bootstrap.min.js"></script>

</body>
</html>*/
echo json_encode($records);?>
